﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Lakshay Punj
//May 2, 2019
//Find Letter

namespace FindLetter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            //todo  - enter code to find the number of times the letter is in the phrase or word

            String Input = txtWord.Text;

            while (Input.Length > 0)
            {
                int Count = 0;
                for (int i=0; i < Input.Length; i++)
                {
                    if (Input[0] == Input[i])
                    {
                        Count++;

                        
                    }
                   
                }


                lblOutput.Text = "The letter occurs " + Count + Input[0];
                

            }
            

        }
    }
}
